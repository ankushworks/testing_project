package com.Social11.service;

public interface IjavaMailService {

	public String SendMailToEmail(String email,long otp); 
	
}
