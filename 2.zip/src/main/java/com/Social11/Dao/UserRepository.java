package com.Social11.Dao;

import com.Social11.models.UserEntity;

public class UserRepository {

}
